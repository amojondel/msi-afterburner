﻿$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$target = 'C:\Program Files (x86)\RivaTuner Statistics Server\Profiles\Global'
$source = Join-Path $root 'RivaTuner Statistics Server\Profiles\Global'
$backup = Join-Path $root 'RTSS-Global.before-position-fix'
$log = Join-Path $root 'RTSS-position-fix.log'
$rtssExe = 'C:\Program Files (x86)\RivaTuner Statistics Server\RTSS.exe'

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -ArgumentList $args
    exit
}

try {
    if (-not (Test-Path -LiteralPath $source)) { throw "Prepared RTSS profile missing: $source" }
    if (-not (Test-Path -LiteralPath $target)) { throw "Installed RTSS profile missing: $target" }
    $prepared = Get-Content -LiteralPath $source -Raw
    if ($prepared -notmatch '(?m)^PositionX=2\s*$' -or $prepared -notmatch '(?m)^PositionY=0\s*$' -or $prepared -notmatch '(?m)^CoordinateSpace=1\s*$') { throw 'Prepared profile values did not pass validation.' }

    Copy-Item -LiteralPath $target -Destination $backup -Force
    Get-Process -Name RTSS -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
    Copy-Item -LiteralPath $source -Destination $target -Force
    Start-Process -FilePath $rtssExe
    $active = Get-Content -LiteralPath $target -Raw
    if ($active -notmatch '(?m)^PositionX=2\s*$' -or $active -notmatch '(?m)^PositionY=0\s*$' -or $active -notmatch '(?m)^CoordinateSpace=1\s*$') { throw 'Active profile verification failed after copy.' }
    "SUCCESS $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n$target`r`nPositionX=2; PositionY=0; CoordinateSpace=1" | Set-Content -LiteralPath $log -Encoding ASCII
} catch {
    "ERROR $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n$($_.Exception.Message)" | Set-Content -LiteralPath $log -Encoding ASCII
    throw
}
